package designpattern.proxy.staticproxy;

/**
 * 接口：租房
 */
public interface IRentingHouse {
    void rentHosue();
}