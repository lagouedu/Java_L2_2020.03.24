package com.lagou.edu.service;

public interface ResumeService {

    Integer findDefaultResumeByUserId(Long userId);
}
